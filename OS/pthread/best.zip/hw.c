#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#define NUM_THREADS 100

void *primes(void *number)
{
		long n = (long)number;
		printf("Prime calculation started for N=%ld!\n",n);
		int counter = 0;

		int checkprime(long n) 
		{
            if (n == 1) return 0;
            else
            {
                for (long i = 2; i <= n / 2; i++) 
                {
                    if (n % i == 0) 
                    {
                        return 0;
                    }
                }
            }

            return 1;
        }
		
        for (long i = 2; i < n; i++)
        {
            int res = checkprime(i);
            if (res == 1) counter++;
        }

        printf("Number of primes for N=%ld is %d\n",n,counter);
        
		pthread_exit(NULL);
}

int main()
{
	pthread_t threads[NUM_THREADS];
	int number = 0;
	int t = 0; 
	
	while(1)
	{
		// if(t > 0) getchar();
		char ch = (char) getc(stdin);
		
		if(ch == 'p')
		{
			scanf("%d",&number);
			int rc = pthread_create(&threads[t],NULL,primes,(void *)number);
			if(rc)
			{
				printf("ERROR: pthread_create() return %d\n",rc);
				exit(-1);
			}

			t++;
		}
		else if(ch == 'e')
		{
			for(int i=0;i<t;i++)
			{
				int rc = pthread_join(threads[i],NULL);
				if(rc)
				{
					printf("ERROR: pthread_join() return %d\n",rc);
					exit(-1);
				}
			}

			break;
		}
		// else
		// {
		// 	printf("Supported commands:\n");
		// 	printf("p N - Starts a new calculation for the number of primes from 1 to N\n");
		// 	printf("e - Waits for all calculations to finish and exits\n");
		// }
	}
	pthread_exit(NULL);
	
	return 0;
}