//------------------------------------------------------------------------
// NAME: Iliyan Tachev
// CLASS: XIb
// NUMBER: 11
// PROBLEM: #2
// FILE NAME: program.c (unix file name)
// FILE PURPOSE:
// реализиране на shell - команден интерпретатор
//------------------------------------------------------------------------

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

//------------------------------------------------------------------------
// FUNCTION: parse_cmdline (име на функцията)
// функцията разделя подадения й стринг на спейсове и връща двумерен масив
// PARAMETERS:
// *cmdline - подаден стринг, съдържащ команди
//------------------------------------------------------------------------

char **parse_cmdline(const char *cmdline);

int main()
{
	
	while(1)						//цикъл, който интерпретира команди до достигане на EOF
	{
   		write(STDOUT_FILENO,"$ ",2);
		char *buffer = NULL;
   		size_t bufsize = 30;

	   	getline(&buffer,&bufsize,stdin);		//четем един ред от команди
	   	
		if(feof(stdin))					//break-ва цикъла ако е достигнато EOF (Ctrl + D)
		{
			free(buffer);
			break;
		}
 
	   	char **result  = parse_cmdline(buffer);		//записваме върнатия от фунвкцията двумерен масив в **result
		free(buffer);

		pid_t pid = fork();				//създаваме процес

		if(pid < 0) 
		{
			perror("fork");

			for(int i = 0; result[i] != NULL; i++)	//в случай на грешка освобождаваме ресурсите на **result
			{
                    		free(result[i]);
                	}

                	free(result);
		}
		else if(pid == 0)
		{
			int res = execv(result[0],result);	//изпълняваме командата

			if(res == -1)
			{	
				perror(result[0]);

				for(int i = 0; result[i] != NULL; i++)  //при грешка освобождаваме ресурсите на **result
				{
                    			free(result[i]);
                		}

                		free(result);
				exit(0);
				
			}
		
		}
		else 
		{
			waitpid(pid,0,0);			//изчакваме child процеса да приключи

			for(int i = 0; result[i] != NULL; i++)	//освобождаваме ресурсите на **result
			{
                	    	free(result[i]);
               		}

                	free(result);
		}

		
	}

	return 0;
}

char **parse_cmdline(const char *cmdline)
{	
	   char *line = malloc (strlen(cmdline) + 1);			//заделяме памет за елементите на cmdline стринга

	   strcpy(line,cmdline);					//line - стрингът приема стойностите на cmdline - 
	   int size = 2,i=0;
	   char **array = malloc(size*sizeof(char*));
	   char *token1;
	   char *token2;
   	   
 	   token1 = strtok(line, "\n");					//token1 - стрингът приема целия ред от команди
	   token2 = strtok(token1," ");					//token2 - стрингът става равен първия стринг от реда

	   while(token2 != NULL ) 					//преминава през всички стрингове до края на cmdline
	   {
		array[i] = malloc ((strlen(token2)+1) * sizeof(char));  //заделя се памет за един стринг
		strcpy(array[i],token2);				//масива array се пълни с елементи (стрингове)
	      	token2 = strtok(NULL, " ");
		i++;

		if(i == size)						
		{
			size = size+1;
			array = realloc(array,size*sizeof(char*));	//паметта се увеличава при повече елементи
		}
	   }

	   array[i] = NULL;						
	   free(line);

      	   return array;						//връщаме двумерния масив
}
